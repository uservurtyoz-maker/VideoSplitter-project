package com.example.videosplitter

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import java.io.File
import java.nio.ByteBuffer
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.max

data class Segment(val startUs: Long, val endUs: Long) {
    val durationSec: Double get() = (endUs - startUs) / 1_000_000.0
}

/**
 * Нарезка без перекодирования: границы ставятся только на ключевых кадрах.
 * Цель каждого куска: 56–60 секунд. Последний кусок может быть короче.
 */
object VideoSplitter {
    const val MIN_SEC = 56.0
    const val MAX_SEC = 60.0

    fun planSegments(context: Context, uri: Uri): List<Segment> {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        val videoIndex = findTrack(extractor, "video/")
        require(videoIndex >= 0) { "В файле нет видеодорожки" }
        extractor.selectTrack(videoIndex)

        val videoFormat = extractor.getTrackFormat(videoIndex)
        val syncUs = ArrayList<Long>()
        var lastUs = 0L
        while (true) {
            val t = extractor.sampleTime
            if (t < 0) break
            if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) syncUs.add(t)
            lastUs = t
            if (!extractor.advance()) break
        }
        extractor.release()

        val totalUs = if (videoFormat.containsKey(MediaFormat.KEY_DURATION))
            videoFormat.getLong(MediaFormat.KEY_DURATION) else lastUs

        val segments = mutableListOf<Segment>()
        var start = 0L
        while (start < totalUs) {
            val remainingSec = (totalUs - start) / 1_000_000.0
            if (remainingSec <= MAX_SEC) {
                segments.add(Segment(start, totalUs))
                break
            }
            val minUs = start + (MIN_SEC * 1_000_000).toLong()
            val maxUs = start + (MAX_SEC * 1_000_000).toLong()
            // Лучший вариант: последний ключевой кадр в окне 56–60 сек
            val cut = syncUs.filter { it in minUs..maxUs }.maxOrNull()
                // Если ключевых кадров в окне нет, берём ближайший после окна
                ?: syncUs.firstOrNull { it > maxUs }
                ?: totalUs
            segments.add(Segment(start, cut))
            start = cut
        }
        return segments
    }

    fun exportSegment(context: Context, uri: Uri, seg: Segment, outFile: File) {
        val extractor = MediaExtractor()
        extractor.setDataSource(context, uri, null)
        val muxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)

        val trackMap = HashMap<Int, Int>()
        for (i in 0 until extractor.trackCount) {
            val format = extractor.getTrackFormat(i)
            val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
            if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                extractor.selectTrack(i)
                trackMap[i] = muxer.addTrack(format)
            }
        }
        muxer.start()

        // Старт сегмента всегда на ключевом кадре, поэтому seek точный
        extractor.seekTo(seg.startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

        val buf = ByteBuffer.allocate(8 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            val track = extractor.sampleTrackIndex
            if (track < 0) break
            val t = extractor.sampleTime
            if (t >= seg.endUs) break
            if (t < seg.startUs) {
                extractor.advance()
                continue
            }
            val outTrack = trackMap[track]
            if (outTrack != null) {
                buf.clear()
                val size = extractor.readSampleData(buf, 0)
                if (size >= 0) {
                    info.offset = 0
                    info.size = size
                    info.presentationTimeUs = max(0L, t - seg.startUs)
                    info.flags = if (extractor.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0)
                        MediaCodec.BUFFER_FLAG_KEY_FRAME else 0
                    muxer.writeSampleData(outTrack, buf, info)
                }
            }
            if (!extractor.advance()) break
        }

        muxer.stop()
        muxer.release()
        extractor.release()
    }

    fun zip(files: List<File>, out: File) {
        ZipOutputStream(out.outputStream().buffered()).use { zos ->
            files.forEach { f ->
                zos.putNextEntry(ZipEntry(f.name))
                f.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun findTrack(extractor: MediaExtractor, prefix: String): Int {
        for (i in 0 until extractor.trackCount) {
            if (extractor.getTrackFormat(i).getString(MediaFormat.KEY_MIME)?.startsWith(prefix) == true) return i
        }
        return -1
    }
}
