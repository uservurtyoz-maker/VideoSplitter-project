package com.example.videosplitter

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.abs

/**
 * Дорожка видео. Оранжевые маркеры — границы отрезков.
 * Маркер можно двигать, он прилипает к ближайшему ключевому кадру.
 */
class TimelineView @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {

    private var durationUs = 0L
    private var keyframes: List<Long> = emptyList()
    private val cuts = mutableListOf<Long>()   // внутренние границы, без 0 и конца
    private var dragIndex = -1
    var onCutsChanged: ((List<Long>) -> Unit)? = null

    private val pad = 48f
    private val barPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF3F51B5.toInt(); strokeWidth = 14f }
    private val cutPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFF5722.toInt(); strokeWidth = 8f }

    fun setData(durationUs: Long, keyframes: List<Long>, cuts: List<Long>) {
        this.durationUs = durationUs
        this.keyframes = keyframes
        this.cuts.clear()
        this.cuts.addAll(cuts)
        invalidate()
    }

    private fun usToX(us: Long): Float =
        pad + (width - 2 * pad) * us.toFloat() / durationUs

    private fun xToUs(x: Float): Long {
        val f = ((x - pad) / (width - 2 * pad)).coerceIn(0f, 1f)
        return (f * durationUs).toLong()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (durationUs <= 0 || width <= 2 * pad) return
        val y = height / 2f
        canvas.drawLine(pad, y, width - pad, y, barPaint)
        for (c in cuts) {
            val x = usToX(c)
            canvas.drawLine(x, y - 40f, x, y + 40f, cutPaint)
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragIndex = cuts.indices.minByOrNull { abs(usToX(cuts[it]) - event.x) } ?: -1
                if (dragIndex >= 0 && abs(usToX(cuts[dragIndex]) - event.x) > 60f) dragIndex = -1
                if (dragIndex >= 0) parent?.requestDisallowInterceptTouchEvent(true)
                return dragIndex >= 0
            }
            MotionEvent.ACTION_MOVE -> if (dragIndex >= 0) {
                val lo = if (dragIndex == 0) 0L else cuts[dragIndex - 1]
                val hi = if (dragIndex == cuts.size - 1) durationUs else cuts[dragIndex + 1]
                val target = xToUs(event.x)
                val candidates = keyframes.filter { it > lo && it < hi }
                if (candidates.isNotEmpty()) {
                    cuts[dragIndex] = candidates.minByOrNull { abs(it - target) }!!
                }
                invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragIndex >= 0) {
                dragIndex = -1
                onCutsChanged?.invoke(cuts.toList())
            }
        }
        return true
    }
}
