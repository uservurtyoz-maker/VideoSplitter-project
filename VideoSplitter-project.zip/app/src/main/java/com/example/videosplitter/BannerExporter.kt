package com.example.videosplitter

import android.content.Context
import android.net.Uri
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

/**
 * Сборка отрезка с баннерами: основное видео до баннера, баннер со звуком,
 * потом основное видео дальше. Все части приводятся к высоте 720.
 */
@OptIn(UnstableApi::class)
object BannerExporter {

    private fun effects() = Effects(emptyList(), listOf(Presentation.createForHeight(720)))

    private fun mainPiece(uri: Uri, startMs: Long, endMs: Long): EditedMediaItem {
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(startMs)
            .setEndPositionMs(endMs)
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()
        return EditedMediaItem.Builder(item).setEffects(effects()).build()
    }

    fun buildComposition(main: Uri, banner: Uri, seg: Segment, bannerSec: List<Double>): Composition {
        val segStartMs = seg.startUs / 1000
        val segEndMs = seg.endUs / 1000
        val items = mutableListOf<EditedMediaItem>()
        var cursor = segStartMs
        for (t in bannerSec) {
            val at = segStartMs + (t * 1000).toLong()
            items.add(mainPiece(main, cursor, at))
            items.add(EditedMediaItem.Builder(MediaItem.fromUri(banner)).setEffects(effects()).build())
            cursor = at
        }
        items.add(mainPiece(main, cursor, segEndMs))
        return Composition.Builder(EditedMediaItemSequence(items)).build()
    }

    /** Перекодирует весь файл в чистый MP4 (H.264 + AAC) без изменения размера. */
    fun reencodeAll(
        context: Context,
        input: Uri,
        out: File,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ): Transformer {
        val item = EditedMediaItem.Builder(MediaItem.fromUri(input)).build()
        val comp = Composition.Builder(EditedMediaItemSequence(listOf(item))).build()
        return start(context, comp, out, onOk, onErr)
    }

    /** Должен вызываться на главном потоке. Возвращает Transformer, его нужно держать в памяти. */
    fun start(
        context: Context,
        composition: Composition,
        out: File,
        onOk: () -> Unit,
        onErr: (String) -> Unit
    ): Transformer {
        val transformer = Transformer.Builder(context)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    onOk()
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException
                ) {
                    val cause = exception.cause?.message ?: "нет"
                    onErr("${exception.message} (код ${exception.errorCode}, причина: $cause)")
                }
            })
            .build()
        transformer.start(composition, out.absolutePath)
        return transformer
    }
}
