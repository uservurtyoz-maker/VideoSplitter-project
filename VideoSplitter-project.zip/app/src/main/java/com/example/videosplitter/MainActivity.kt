package com.example.videosplitter

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var btnExport: Button
    private var videoUri: Uri? = null
    private var segments: List<Segment> = emptyList()

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            videoUri = uri
            analyze(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvInfo = findViewById(R.id.tvInfo)
        btnExport = findViewById(R.id.btnExport)

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        btnExport.setOnClickListener { export() }
    }

    private fun analyze(uri: Uri) {
        tvInfo.text = "Анализ видео..."
        btnExport.isEnabled = false
        Thread {
            try {
                val segs = VideoSplitter.planSegments(this, uri)
                runOnUiThread {
                    segments = segs
                    val minSec = segs.minOf { it.durationSec }
                    val maxSec = segs.maxOf { it.durationSec }
                    tvInfo.text = "Отрезков: ${segs.size}\n" +
                        "Длительность: от %.1f до %.1f сек".format(minSec, maxSec)
                    btnExport.isEnabled = segs.isNotEmpty()
                }
            } catch (e: Exception) {
                runOnUiThread { tvInfo.text = "Ошибка анализа: ${e.message}" }
            }
        }.start()
    }

    private fun export() {
        val uri = videoUri ?: return
        val segs = segments
        btnExport.isEnabled = false
        tvInfo.text = "Экспорт: 0 из ${segs.size}"
        Thread {
            try {
                val dir = File(getExternalFilesDir(null), "export")
                dir.deleteRecursively()
                dir.mkdirs()
                val files = segs.mapIndexed { i, s ->
                    val f = File(dir, "part_%03d.mp4".format(i + 1))
                    VideoSplitter.exportSegment(this, uri, s, f)
                    runOnUiThread { tvInfo.text = "Экспорт: ${i + 1} из ${segs.size}" }
                    f
                }
                val zip = File(getExternalFilesDir(null), "segments.zip")
                VideoSplitter.zip(files, zip)
                files.forEach { it.delete() }
                dir.delete()
                runOnUiThread {
                    tvInfo.text = "Готово: ${zip.absolutePath}"
                    btnExport.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvInfo.text = "Ошибка экспорта: ${e.message}"
                    btnExport.isEnabled = true
                }
            }
        }.start()
    }
}
