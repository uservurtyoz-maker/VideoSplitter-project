package com.example.videosplitter

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.transformer.Transformer
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var timeline: TimelineView
    private lateinit var etCount: EditText
    private lateinit var etFirst: EditText
    private lateinit var etInterval: EditText
    private lateinit var tvBanner: TextView
    private lateinit var btnExport: Button

    private var mainUri: Uri? = null
    private var bannerUri: Uri? = null
    private var info: VideoSplitter.Info? = null
    private var innerCuts: List<Long> = emptyList()   // границы без 0 и конца
    private var transformer: Transformer? = null
    private var localMain: Uri? = null
    private var localBanner: Uri? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            mainUri = uri
            analyze(uri)
        }
    }

    private val pickBanner = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            bannerUri = uri
            tvBanner.text = "Баннер выбран"
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvInfo = findViewById(R.id.tvInfo)
        timeline = findViewById(R.id.timeline)
        etCount = findViewById(R.id.etCount)
        etFirst = findViewById(R.id.etFirst)
        etInterval = findViewById(R.id.etInterval)
        tvBanner = findViewById(R.id.tvBanner)
        btnExport = findViewById(R.id.btnExport)

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        findViewById<Button>(R.id.btnBanner).setOnClickListener {
            pickBanner.launch(arrayOf("video/*"))
        }
        timeline.onCutsChanged = { cuts ->
            innerCuts = cuts
            updateSummary()
        }
        btnExport.setOnClickListener { startExport() }
    }

    private fun analyze(uri: Uri) {
        setStatus("Анализ видео...")
        btnExport.isEnabled = false
        Thread {
            try {
                val i = VideoSplitter.readInfo(this, uri)
                val full = VideoSplitter.planCuts(i)
                runOnUiThread {
                    info = i
                    innerCuts = full.drop(1).dropLast(1)
                    timeline.setData(i.durationUs, i.keyframesUs, innerCuts)
                    updateSummary()
                    btnExport.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { setStatus("Ошибка анализа: ${e.message}") }
            }
        }.start()
    }

    private fun segments(): List<Segment> {
        val d = info?.durationUs ?: return emptyList()
        val points = listOf(0L) + innerCuts + listOf(d)
        return points.zipWithNext { a, b -> Segment(a, b) }
    }

    private fun updateSummary() {
        val segs = segments()
        if (segs.isEmpty()) return
        val minSec = segs.minOf { it.durationSec }
        val maxSec = segs.maxOf { it.durationSec }
        setStatus("Отрезков: ${segs.size}\nДлительность: от %.1f до %.1f сек".format(minSec, maxSec))
    }

    private fun setStatus(text: String) {
        tvInfo.text = text
    }

    /** Времена баннеров внутри отрезка, в секундах от его начала. */
    private fun bannerTimes(seg: Segment): List<Double> {
        if (bannerUri == null) return emptyList()
        val count = etCount.text.toString().toIntOrNull()?.coerceIn(0, 10) ?: 0
        val first = etFirst.text.toString().toDoubleOrNull() ?: 5.0
        val interval = (etInterval.text.toString().toDoubleOrNull() ?: 10.0).takeIf { it > 0 } ?: 10.0
        val len = seg.durationSec
        return (0 until count)
            .map { first + it * interval }
            .filter { it > 0.5 && it < len - 1.0 }
    }

    private fun startExport() {
        val main = mainUri ?: return
        if (info == null) return
        btnExport.isEnabled = false
        setStatus("Подготовка файлов...")
        Thread {
            try {
                val m = copyToLocal(main, "main_source")
                val b = bannerUri?.let { copyToLocal(it, "banner_source") }
                runOnUiThread {
                    localMain = m
                    localBanner = b
                    val dir = File(getExternalFilesDir(null), "export").apply {
                        deleteRecursively()
                        mkdirs()
                    }
                    if (b == null) {
                        exportNext(0, segments(), dir, mutableListOf())
                    } else {
                        setStatus("Подготовка основного видео (может занять время)...")
                        val clean = File(filesDir, "main_clean.mp4")
                        if (clean.exists()) clean.delete()
                        transformer = BannerExporter.reencodeAll(
                            this, m, clean,
                            onOk = {
                                localMain = Uri.fromFile(clean)
                                exportNext(0, segments(), dir, mutableListOf())
                            },
                            onErr = { msg -> failExport("подготовка видео: $msg") }
                        )
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { failExport("не удалось подготовить файл: ${e.message}") }
            }
        }.start()
    }

    /** Копирует файл из выбора системы в папку приложения, чтобы Media3 мог его открыть. */
    private fun copyToLocal(uri: Uri, name: String): Uri {
        val target = File(filesDir, name)
        val input = contentResolver.openInputStream(uri) ?: error("файл недоступен")
        input.use { src -> target.outputStream().use { dst -> src.copyTo(dst) } }
        return Uri.fromFile(target)
    }

    /** Все вызовы этой функции идут с главного потока. */
    private fun exportNext(i: Int, segs: List<Segment>, dir: File, done: MutableList<File>) {
        if (i >= segs.size) {
            zipAll(done)
            return
        }
        val uri = localMain ?: return
        val seg = segs[i]
        val out = File(dir, "part_%03d.mp4".format(i + 1))
        setStatus("Экспорт ${i + 1} из ${segs.size}")

        val banners = bannerTimes(seg)
        val banner = localBanner
        if (banners.isEmpty() || banner == null) {
            Thread {
                try {
                    VideoSplitter.exportSegment(this, uri, seg, out)
                    runOnUiThread {
                        done.add(out)
                        exportNext(i + 1, segs, dir, done)
                    }
                } catch (e: Exception) {
                    runOnUiThread { failExport(e.message) }
                }
            }.start()
        } else {
            val comp = BannerExporter.buildComposition(uri, banner, seg, banners)
            transformer = BannerExporter.start(
                this, comp, out,
                onOk = {
                    done.add(out)
                    exportNext(i + 1, segs, dir, done)
                },
                onErr = { msg -> failExport(msg) }
            )
        }
    }

    private fun zipAll(files: List<File>) {
        setStatus("Упаковка в ZIP...")
        Thread {
            try {
                val zip = File(getExternalFilesDir(null), "segments.zip")
                VideoSplitter.zip(files, zip)
                files.forEach { it.delete() }
                runOnUiThread {
                    setStatus("Готово: ${zip.absolutePath}")
                    btnExport.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread { failExport(e.message) }
            }
        }.start()
    }

    private fun failExport(msg: String?) {
        setStatus("Ошибка экспорта: $msg")
        btnExport.isEnabled = true
    }
}
