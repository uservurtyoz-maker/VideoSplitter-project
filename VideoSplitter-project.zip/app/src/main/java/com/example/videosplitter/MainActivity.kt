package com.example.videosplitter

import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File

@OptIn(UnstableApi::class)
class MainActivity : AppCompatActivity() {

    private lateinit var tvInfo: TextView
    private lateinit var btnExport: Button
    private var videoUri: Uri? = null
    private var segments: List<Segment> = emptyList()
    private var transformer: Transformer? = null

    private val pickVideo = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) analyze(uri, allowConvert = true)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvInfo = findViewById(R.id.tvInfo)
        btnExport = findViewById(R.id.btnExport)

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            pickVideo.launch(arrayOf("video/*"))
        }
        btnExport.setOnClickListener { export() }
    }

    private fun analyze(uri: Uri, allowConvert: Boolean) {
        tvInfo.text = "Анализ видео..."
        btnExport.isEnabled = false
        Thread {
            try {
                val segs = VideoSplitter.planSegments(this, uri)
                runOnUiThread { showSegments(uri, segs) }
            } catch (e: Exception) {
                runOnUiThread {
                    if (allowConvert) convertToMp4(uri)
                    else tvInfo.text = "Ошибка анализа: ${e.message}"
                }
            }
        }.start()
    }

    private fun showSegments(uri: Uri, segs: List<Segment>) {
        videoUri = uri
        segments = segs
        if (segs.isEmpty()) {
            tvInfo.text = "Отрезков нет, видео пустое"
            return
        }
        val minSec = segs.minOf { it.durationSec }
        val maxSec = segs.maxOf { it.durationSec }
        tvInfo.text = "Отрезков: ${segs.size}\n" +
            "Длительность: от %.1f до %.1f сек".format(minSec, maxSec)
        btnExport.isEnabled = true
    }

    /** Разовая конвертация WebM и других форматов в MP4 (H.264 + AAC) внутри приложения. */
    private fun convertToMp4(src: Uri) {
        val out = File(getExternalFilesDir(null), "converted.mp4")
        if (out.exists()) out.delete()
        tvInfo.text = "Формат напрямую не открывается, конвертирую в MP4.\n" +
            "Это займёт время, не закрывай приложение."

        transformer = Transformer.Builder(this)
            .setVideoMimeType(MimeTypes.VIDEO_H264)
            .setAudioMimeType(MimeTypes.AUDIO_AAC)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, result: ExportResult) {
                    val convertedUri = Uri.fromFile(out)
                    analyze(convertedUri, allowConvert = false)
                }

                override fun onError(
                    composition: Composition,
                    result: ExportResult,
                    exception: ExportException
                ) {
                    tvInfo.text = "Конвертация не удалась: ${exception.message}"
                }
            })
            .build()

        val item = EditedMediaItem.Builder(MediaItem.fromUri(src)).build()
        transformer?.start(item, out.absolutePath)
    }

    private fun export() {
        val uri = videoUri ?: return
        val segs = segments
        btnExport.isEnabled = false
        tvInfo.text = "Экспорт: 0 из ${segs.size}"
        Thread {
            try {
                val dir = File(getExternalFilesDir(null), "export")
                dir.deleteRecursively()
                dir.mkdirs()
                val files = segs.mapIndexed { i, s ->
                    val f = File(dir, "part_%03d.mp4".format(i + 1))
                    VideoSplitter.exportSegment(this, uri, s, f)
                    runOnUiThread { tvInfo.text = "Экспорт: ${i + 1} из ${segs.size}" }
                    f
                }
                val zip = File(getExternalFilesDir(null), "segments.zip")
                VideoSplitter.zip(files, zip)
                files.forEach { it.delete() }
                dir.delete()
                runOnUiThread {
                    tvInfo.text = "Готово: ${zip.absolutePath}"
                    btnExport.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    tvInfo.text = "Ошибка экспорта: ${e.message}"
                    btnExport.isEnabled = true
                }
            }
        }.start()
    }
}
